## RGB-A ##

On GitHub https://github.com/hurdleg/RGBA.git

Please read my //TODO comments for you :)
> View > Tool Windows > TODO